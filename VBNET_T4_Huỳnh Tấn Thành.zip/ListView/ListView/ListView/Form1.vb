﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Try
            If TextBox1.Text / 1 And TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" And TextBox4.Text <> "" And ComboBox1.Text <> "" Then
                Dim lvi As ListViewItem
                lvi = New ListViewItem(TextBox1.Text)
                lvi.SubItems.Add(TextBox2.Text)
                lvi.SubItems.Add(TextBox3.Text)
                lvi.SubItems.Add(ComboBox1.SelectedItem.ToString)
                lvi.SubItems.Add(TextBox4.Text)
                Dim check As Boolean
                check = False
                If lv.Items.Count > 0 Then
                    For Each item In lv.Items
                        Dim currItem As ListViewItem = item
                        If currItem.SubItems(2).Text = TextBox3.Text Then
                            MsgBox("Sinh viên đã tồn tại!", MsgBoxStyle.OkOnly, "")
                            check = True
                        End If
                    Next
                    If check = False Then
                        lv.Items.Add(lvi)
                    End If
                Else
                    lv.Items.Add(lvi)
                End If
                TextBox1.Text = ""
                TextBox2.Text = ""
                TextBox3.Text = ""
                ComboBox1.Text = ""
                TextBox4.Text = ""
                TextBox1.Focus()
            End If
        Catch ex As Exception
            MsgBox("không hợp lệ!", MsgBoxStyle.OkOnly, "")
            TextBox1.Clear()
            TextBox1.Focus()
        End Try
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        If lv.SelectedItems.Count <> 0 Then
            If TextBox1.Text = "" And TextBox2.Text = "" And TextBox3.Text = "" And TextBox4.Text = "" And ComboBox1.Text = "" Then
                Dim item As ListViewItem
                For Each item In lv.SelectedItems
                    TextBox1.Text = item.SubItems(0).Text
                    TextBox2.Text = item.SubItems(1).Text
                    TextBox3.Text = item.SubItems(2).Text
                    ComboBox1.Text = item.SubItems(3).Text
                    TextBox4.Text = item.SubItems(4).Text
                Next
            Else
                Dim a As MsgBoxResult = MsgBox("Bạn có muốn sửa?", MsgBoxStyle.YesNo, "")
                If a = MsgBoxResult.Yes Then
                    Dim item As ListViewItem
                    item = lv.SelectedItems(0)
                    item.SubItems(0).Text = TextBox1.Text
                    item.SubItems(1).Text = TextBox2.Text
                    item.SubItems(2).Text = TextBox3.Text
                    item.SubItems(3).Text = ComboBox1.Text
                    item.SubItems(4).Text = TextBox4.Text
                    TextBox1.Text = ""
                    TextBox2.Text = ""
                    TextBox3.Text = ""
                    TextBox4.Text = ""
                    ComboBox1.Text = ""
                End If
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        If lv.SelectedItems.Count <> 0 Then
            Dim a As MsgBoxResult = MsgBox("Bạn có muốn xóa?", MsgBoxStyle.YesNo, "")
            If a = MsgBoxResult.Yes Then
                Dim temp As ListViewItem
                temp = lv.SelectedItems(0)
                temp.Remove()
            End If
        End If
    End Sub


End Class
